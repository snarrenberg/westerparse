WesterParse Web Site
====================

.. image:: images/WesterParseWebFlow.png
  :width: 400
  :alt: WesterParse Web Flow Chart
  :align: center


Westegaardian Species Counterpoint Online
-----------------------------------------

https://talus.artsci.wustl.edu/counterpoint_tester/

The web interface was written by Stephen Pentecost, Senior Digital Humanities Specialist at Washington University in St. Louis. 

